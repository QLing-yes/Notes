## 绑定点击事件

```
        this.voice.on(Laya.Event.MOUSE_DOWN, this, () => {});
```

