

- 速度==方向*时间
- 速率==力量*时间
- new新对象消耗大; xxx.Set()取代

# 函数

- FixedUpdate - 固定帧更新

- [OnCollisionEnter2D(Collision2D col)](https://docs.unity3d.com/cn/2020.3/ScriptReference/MonoBehaviour.OnCollisionEnter.html) - 发生碰撞事件调用

  > 入参,碰撞信息和他撞了谁

# 方法

- [Input.GetAxisRaw(`<string axisName>`)](https://docs.unity3d.com/ScriptReference/Input.GetAxisRaw.html) - 获取输入轴向

